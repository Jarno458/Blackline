﻿namespace Blackline.Data
{
	public enum BlackLineType
	{
		Personal,
		Critical,
		Medical,
		OIther,
	}
}